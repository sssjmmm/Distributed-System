import re
import json

log_file_path = 'output_log.log'  # Replace with the actual path to your log file

# Define regular expressions to match log patterns
update_pattern = re.compile(r'\[RECEIVE-ANALYZE\] received update message.*?host=(.*?), state=(.*?), incarnation=(\d+)')
event_pattern = re.compile(r'\[EVENT\] No subscribers registered for event class (.*?)(\n|$)')
member_list_pattern = re.compile(r'\[MEMBER-LIST\] \[.*?\] (.*?)(\n|$)')

# Dictionary to store counts
log_counts = {
    "update_messages": 0,
    "event_messages": 0,
    "member_list_messages": 0,
}

# Lists to store details
update_details = []
event_details = []
member_list_details = []

with open(log_file_path, 'r', encoding='utf-8') as log_file:
    for line in log_file.readlines():
        # Check for update messages
        update_match = update_pattern.search(line)
        if update_match:
            log_counts["update_messages"] += 1
            host, state, incarnation = update_match.groups()
            update_details.append({"host": host, "state": state, "incarnation": int(incarnation)})

        # Check for event messages
        event_match = event_pattern.search(line)
        if event_match:
            log_counts["event_messages"] += 1
            event_class = event_match.group(1)
            event_details.append({"event_class": event_class})

        # Check for member list messages
        member_list_match = member_list_pattern.search(line)
        if member_list_match:
            log_counts["member_list_messages"] += 1
            member_list_details.append({"members": eval(member_list_match.group(1))})

# Output the counts and details in JSON format
result = {"log_counts": log_counts, "update_details": update_details, "event_details": event_details, "member_list_details": member_list_details}

output_json_path = 'output.json'  # Replace with the desired output file path

with open(output_json_path, 'w') as json_file:
    json.dump(result, json_file, indent=2)

print(f"Extraction complete. Results saved in {output_json_path}")
