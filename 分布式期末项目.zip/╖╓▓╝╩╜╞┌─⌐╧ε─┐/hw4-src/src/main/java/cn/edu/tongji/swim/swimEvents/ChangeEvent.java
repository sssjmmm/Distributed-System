package cn.edu.tongji.swim.swimEvents;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ChangeEvent {
}
