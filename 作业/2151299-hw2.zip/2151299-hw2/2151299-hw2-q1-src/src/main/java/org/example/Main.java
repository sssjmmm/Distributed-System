package org.example;

import java.io.*;
import java.util.Random;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import java.io.IOException;

public class Main {


    public static void main(String[] args) {
        try {
            Random random = new Random(244);

            // 创建两个临时的dat文件，用于存放每个group的数据，group1直接存进最终文件中
            RandomAccessFile group2Writer = new RandomAccessFile("group2.dat", "rw");
            RandomAccessFile group3Writer = new RandomAccessFile("group3.dat", "rw");
            RandomAccessFile h2q1Writer = new RandomAccessFile("h2q1.dat", "rw");

            int bufferSize = 1024*16;
            // 创建一个 ByteBuffer 用于暂时存储 double 数值，对应每个 group
            ByteBuffer bufferGroup1 = ByteBuffer.allocate(bufferSize);
            ByteBuffer bufferGroup2 = ByteBuffer.allocate(bufferSize);
            ByteBuffer bufferGroup3 = ByteBuffer.allocate(bufferSize);

            // 给三个文件建立三个通道
            FileChannel file1Channel = h2q1Writer.getChannel();
            FileChannel file2Channel = group2Writer.getChannel();
            FileChannel file3Channel = group3Writer.getChannel();

            int totalPairs = 0; // 所有数对个数
            int countAbove0_5 = 0; // 数对中大于0.5的double数值个数（数对中无论d1或者d2大于0.5均计入统计）
            int countBothAbove0_5 = 0; // 数对中大于0.5的double数对个数（数对中d1和d2都大于0.5才计入统计）
            int group1Count = 0; // group1所含数对个数
            int group2Count = 0; // group2所含数对个数
            int group3Count = 0; // group3所含数对个数
            int group1Pos ; // group1所含数对起始字节位置
            int group2Pos ; // group2所含数对起始字节位置
            int group3Pos ; // group3所含数对起始字节位置

            // 留32位作为文件头
            file1Channel.position(32);

            long startTime = System.currentTimeMillis();

            while (true) {
                double d1 = random.nextDouble();
                double d2 = random.nextDouble();

                if(d1>0.5){
                    countAbove0_5++;
                }
                if(d2>0.5){
                    countAbove0_5++;
                }

                if (d1 > 0.5 && d2 > 0.5) { // 两个数都大于0.5
                    countBothAbove0_5++;
                }

                // 根据条件将 double 数值写入相应的 ByteBuffer
                if (d1 < 0.46 && d2 < 0.46) {
                    // 把double写入缓冲区
                    bufferGroup1.putDouble(d1);
                    bufferGroup1.putDouble(d2);
                    group1Count++;
                } else if (d1 > 0.72 && d2 > 0.72) {
                    bufferGroup3.putDouble(d1);
                    bufferGroup3.putDouble(d2);
                    group3Count++;
                } else {
                    bufferGroup2.putDouble(d1);
                    bufferGroup2.putDouble(d2);
                    group2Count++;
                }

                // 当缓冲区满了就可以写入文件
                if (bufferGroup1.remaining() < 16) {
                    bufferGroup1.flip(); // 切换到读模式
                    // 将 ByteBuffer 中的数据一次性写入文件
                    file1Channel.write(bufferGroup1);
                    bufferGroup1.clear(); // 清空ByteBuffer
                }
                if (bufferGroup2.remaining() < 16) {
                    bufferGroup2.flip(); // 切换到读模式
                    // 将 ByteBuffer 中的数据一次性写入文件
                    file2Channel.write(bufferGroup2);
                    bufferGroup2.clear(); // 清空ByteBuffer
                }
                if (bufferGroup3.remaining() < 16) {
                    bufferGroup3.flip(); // 切换到读模式
                    // 将 ByteBuffer 中的数据一次性写入文件
                    file3Channel.write(bufferGroup3);
                    bufferGroup3.clear(); // 清空ByteBuffer
                }
                // 终止条件
                if (d1 > 0.997 && d2 > 0.997) {
                    break;
                }
            }


            // 如果 ByteBuffer 中还有剩余数据，写入相应的 group 文件
            if(bufferGroup1.hasRemaining()){
                bufferGroup1.flip(); // 切换到读模式
                // 将 ByteBuffer 中的数据一次性写入文件
                file1Channel.write(bufferGroup1);
                bufferGroup1.clear(); // 清空 ByteBuffer
            }
            if(bufferGroup2.hasRemaining()){
                bufferGroup2.flip(); // 切换到读模式
                // 将 ByteBuffer 中的数据一次性写入文件
                file2Channel.write(bufferGroup2);
                bufferGroup2.clear(); // 清空 ByteBuffer
            }
            if(bufferGroup3.hasRemaining()){
                bufferGroup3.flip(); // 切换到读模式
                // 将 ByteBuffer 中的数据一次性写入文件
                file3Channel.write(bufferGroup3);
                bufferGroup3.clear(); // 清空 ByteBuffer
            }



            // 计算三个group的起始字节位置和总数对个数
            group1Pos = 32;
            group2Pos = group1Pos + group1Count * 16;
            group3Pos = group2Pos + group2Count * 16;
            totalPairs = group1Count + group2Count + group3Count; // 总数对个数

            // 先放入一个空的缓冲区
            bufferGroup1.putInt(totalPairs);
            bufferGroup1.putInt(group1Count);
            bufferGroup1.putInt(group1Pos);
            bufferGroup1.putInt(group2Count);
            bufferGroup1.putInt(group2Pos);
            bufferGroup1.putInt(group3Count);
            bufferGroup1.putInt(group3Pos);

            // 再放入最终文件
            bufferGroup1.flip();
            file1Channel.position(0); // 指针置于起始位置开始写入文件头
            file1Channel.write(bufferGroup1);
            bufferGroup1.clear();

            // 整合三个临时文件到最终的 h2q1.dat 文件
            file1Channel.position(group2Pos); // 指针跳到最终文件的末尾
            file2Channel.transferTo(0, file2Channel.size(), file1Channel); // 追加文件
            file3Channel.transferTo(0, file3Channel.size(), file1Channel);


            long endTime = System.currentTimeMillis();
            long elapsedTime = endTime - startTime;


            System.out.println("Count Above 0.5: " + countAbove0_5);
            System.out.println("Count Both Above 0.5: " + countBothAbove0_5);
            System.out.println("Elapsed Time (ms): " + elapsedTime);


            // 关闭文件的写入流
            group2Writer.close();
            group3Writer.close();
            h2q1Writer.close();

            file1Channel.close();
            file2Channel.close();
            file3Channel.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
