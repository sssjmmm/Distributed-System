package org.example;

import org.graphstream.graph.Edge;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.view.Viewer;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.HashSet;
import java.util.Set;


public class Main {

    //    static String startUrl="http://www.tongji.edu.cn"; // 开始Url
    private static final Set<String> startUrls = new HashSet<>();
    private static final Set<String> visitedUrls = new HashSet<>();
    private static final Graph graph = new SingleGraph("URLGraph");
    private static final Set<String> addedNodes = new HashSet<>();
    private static final Set<String> addedEdges = new HashSet<>();

    public static void main(String[] args) {

        startUrls.add("http://www.tongji.edu.cn");
        startUrls.add("http://www.pku.cn");
        startUrls.add("http://www.sina.com.cn");
        startUrls.add("http://www.mit.edu");

        long startTime = System.currentTimeMillis();//记录跳转网页的时间
        for (String startUrl : startUrls) {
            crawl(startUrl, 0);
        }
        long endTime = System.currentTimeMillis();
        double elapsedTime = (double)(endTime - startTime)/1000.0;


        int nodeCount = graph.getNodeCount();
        int edgeCount = graph.getEdgeCount();

        System.out.println("结点数：" + nodeCount);
        System.out.println("边数：" + edgeCount);
        // 找到包含最多入边的节点URL
        String maxInDegreeNodeURL = findNodeWithMaxInDegree();
        System.out.println("最大入度的结点：" + maxInDegreeNodeURL);
        System.out.println("所用时间：" + elapsedTime + "秒");

        // 创建一个图形视图
        Viewer viewer = graph.display();
        viewer.enableAutoLayout();
        // 设置节点样式
        for (Node node : graph) {
            node.addAttribute("ui.style", "size: 8px; fill-mode: gradient-radial; fill-color: #ffaabb;text-size: 20px; text-color: #FFbbaa;");
        }

        // 设置边样式
        for (Edge edge : graph.getEachEdge()) {
            edge.addAttribute("ui.style", "fill-color: #aabbff; size: 2px;");
        }

        // 等待直到窗口关闭
        viewer.setCloseFramePolicy(Viewer.CloseFramePolicy.HIDE_ONLY);
    }
    private static void crawl(String url, int depth)  {
        if (depth > 3 || visitedUrls.contains(url)) {
            return;
        }
        visitedUrls.add(url); // 加入访问过的url集合

        try{
            Document htmlDocument = Jsoup.connect(url).timeout(3000).get();

            Elements links = htmlDocument.select("a[href]");
            int linkCount = 0; // 用于计数处理的链接数量
            for (Element link : links) {
                if(linkCount >= 6){
                    break;
                }


                String href = link.attr("abs:href");
                // 此时获得完整url

                // 这些href都是html中的外部链接，接下来筛选出外部url
                if(ifExternalUrl(url,href) && !visitedUrls.contains(href)){
                    linkCount++; // 该层的外部链接计数器++

                    // 在添加节点和边前检查是否已存在
                    if (!addedNodes.contains(url)) {
                        Node tempNode = graph.addNode(url);
                        addedNodes.add(url);
                        tempNode.addAttribute("ui.label", url);
                    }
                    if (!addedNodes.contains(href)) {
                        Node tempNode = graph.addNode(href);
                        addedNodes.add(href);
                        tempNode.addAttribute("ui.label", href);
                    }

                    String edgeId = url + "-" + href;
                    if (!addedEdges.contains(edgeId)) {
                        Node sourceNode = graph.getNode(url);
                        Node targetNode = graph.getNode(href);
                        graph.addEdge(edgeId, sourceNode, targetNode, true);
                        addedEdges.add(edgeId);
                    }

                    System.out.println(url + "-->" + href);
                    crawl(href, depth + 1);
                }
            }
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public static boolean ifExternalUrl(String sourceURL, String targetURL){
        try {
            URI sourceURI = new URI(sourceURL);
            URI targetURI = new URI(targetURL);

            String sourceHost = sourceURI.getHost();
            String targetHost = targetURI.getHost();

            if (sourceHost == null || targetHost == null) {
                // 无法解析主机名，不符合要求
                return false;
            }

            // 切分主机名，获取最右的子域名
            String[] sourceDomainParts = sourceHost.split("\\.");
            String[] targetDomainParts = targetHost.split("\\.");

            int sourceLength = sourceDomainParts.length;
            int targetLength = targetDomainParts.length;

            if (sourceLength < 3 || targetLength < 3) {
                // 不符合要求，主域名部分至少包括三个子域名
                return false;
            }

            // 比较最右的子域名
            int commonSubdomains = 0;
            for (int i = 1; i <= 3; i++) {
                if (sourceDomainParts[sourceLength - i].equals(targetDomainParts[targetLength - i])) {
                    commonSubdomains++;
                }
            }

            // 域名不同于当前机构，并且最右后缀子域名至多有1个或2个相同
            return !sourceHost.equals(targetHost) && (commonSubdomains <= 2);
        } catch (URISyntaxException e) {
            // URL格式不正确，不符合要求
            return false;
        }
    }
    private static String findNodeWithMaxInDegree() {
        int maxInDegree = -1;
        String maxInDegreeNodeURL = null;

        for (Node node : Main.graph) {
            int inDegree = node.getInDegree();
            if (inDegree > maxInDegree) {
                maxInDegree = inDegree;
                maxInDegreeNodeURL = node.getId();
            }
        }

        return maxInDegreeNodeURL;
    }
}
