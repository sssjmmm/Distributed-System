package org.example.client;

import org.example.util.SendFile;

import java.io.*;
import java.net.Socket;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Upload {
    protected String filePath;
    protected String fileName;
    protected static final String BASE_CHUNK_FILE_PATH = "./";
    private static final String request = "U";
    protected static final int CHUNK_SIZE = 1024 * 1024;
    protected int chunkCount;
    protected final String hashTableFilePath;
    protected static String SERVER_HOST = "localhost";
    protected static int[] SERVER_PORTS = {6001, 6002, 6003};
    protected Map<Integer, List<Integer>> hash = new HashMap<>();

    public Upload(String filePath) {
        this.filePath = filePath;
        Path path = Paths.get(filePath);
        this.fileName = path.getFileName().toString();
        this.hashTableFilePath = fileName + ".to";
    }
    protected void getChunk() {
        try (RandomAccessFile file = new RandomAccessFile(filePath, "r");
             FileChannel fileChannel = file.getChannel()) {
            long fileSize = file.length();
            chunkCount = (int) Math.ceil((double) fileSize / CHUNK_SIZE);

            for (int i = 0; i < chunkCount; ++i) {
                int chunkIndex = i;
                String chunkFilePath = BASE_CHUNK_FILE_PATH + fileName + "#" + chunkIndex;
                try (RandomAccessFile chunkFile = new RandomAccessFile(chunkFilePath, "rw");
                     FileChannel chunkFileChannel = chunkFile.getChannel()) {
                    long position = (long) chunkIndex * CHUNK_SIZE;
                    long remaining = fileSize - position;
                    long chunkSize = Math.min(CHUNK_SIZE, remaining);
                    fileChannel.transferTo(position, chunkSize, chunkFileChannel);
                } catch (Exception e) {
                    System.out.println(chunkFilePath + " 错误");
                }
            }

        } catch (Exception e) {
            System.out.println(filePath + " 错误");
        }
    }
    protected void deleteChunkFile() {
        ExecutorService executorService = Executors.newFixedThreadPool(chunkCount);
        List<CompletableFuture<Void>> futures = new ArrayList<>();

        for (int i = 0; i < chunkCount; ++i) {
            int chunkIndex = i;
            CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
                Path chunkFilePath = Paths.get(BASE_CHUNK_FILE_PATH + fileName + "#" + chunkIndex);
                if (Files.exists(chunkFilePath)) {
                    try {
                        Files.delete(chunkFilePath);
                    } catch (IOException e) {
                        System.out.println(chunkFilePath + "删除失败");
                    }
                }
            }, executorService);
            futures.add(future);
        }
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        executorService.shutdown();
    }
    protected void allocateChunk() {
        for (int i = 0; i < chunkCount; ++i) {
            Random random = new Random();
            int randomPortIndex = random.nextInt(SERVER_PORTS.length);
            if (hash.containsKey(SERVER_PORTS[randomPortIndex])) {
                List<Integer> v = hash.get(SERVER_PORTS[randomPortIndex]);
                v.add(i);
                hash.put(SERVER_PORTS[randomPortIndex], v);
            } else {
                hash.put(SERVER_PORTS[randomPortIndex], new ArrayList<>(List.of(i)));
            }
        }
    }
    protected void sendChunk() {
        Socket[] sockets = new Socket[SERVER_PORTS.length];
        DataOutputStream[] dataOutputStreams = new DataOutputStream[SERVER_PORTS.length];
        DataInputStream[] dataInputStreams = new DataInputStream[SERVER_PORTS.length];
        try {
            for (int i = 0; i < sockets.length; ++i) {
                if (!hash.containsKey(SERVER_PORTS[i])) {
                    continue;
                }
                sockets[i] = new Socket(SERVER_HOST, SERVER_PORTS[i]);
                dataOutputStreams[i] = new DataOutputStream(sockets[i].getOutputStream());
                dataInputStreams[i] = new DataInputStream(sockets[i].getInputStream());
                dataOutputStreams[i].write(request.getBytes(StandardCharsets.UTF_8));
                byte[] fileNameByte = fileName.getBytes(StandardCharsets.UTF_8);
                dataOutputStreams[i].writeInt(fileNameByte.length);
                dataOutputStreams[i].write(fileNameByte);
                List<Integer> v = hash.get(SERVER_PORTS[i]);
                dataOutputStreams[i].writeInt(v.size());
                for (Integer j: v) {
                    String chunkFilePath = BASE_CHUNK_FILE_PATH + fileName + "#" + j;
                    try (FileChannel fileChannel = FileChannel.open(Paths.get(chunkFilePath), StandardOpenOption.READ)) {
                        dataOutputStreams[i] = new DataOutputStream(sockets[i].getOutputStream());
                        SendFile sendFile = new SendFile(fileName + "#" + j, fileChannel, dataOutputStreams[i]);
                        sendFile.send();
                        dataInputStreams[i].readInt();
                    } catch (IOException e) {
                        System.out.println(filePath + " 错误");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("发送错误");
        } finally {
            for (int i = 0; i < sockets.length; ++i) {
                if (sockets[i] != null && !sockets[i].isClosed()) {
                    try {
                        sockets[i].close();
                    } catch (IOException e) {
                        System.out.println(sockets[i] + " 关闭失败");
                    }
                }
                if (dataOutputStreams[i] != null) {
                    try {
                        dataOutputStreams[i].close();
                    } catch (IOException e) {
                        System.out.println(dataOutputStreams[i] + " 关闭失败");
                    }
                }
                if (dataInputStreams[i] != null) {
                    try {
                        dataInputStreams[i].close();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
    }

    protected void saveHashtable() {
        Path path = Path.of(hashTableFilePath);
        if (!Files.exists(path)) {
            try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                    Files.newOutputStream(path, StandardOpenOption.CREATE)
            )) {
                objectOutputStream.writeObject(hash);
                System.out.println("哈希表保存成功！");
            } catch (IOException e) {
                e.printStackTrace();
            }
//        } else {
//            System.out.println("hash table file exists");
        }
    }

    public static void uploadFile(String filePath) {
        Upload upload = new Upload(filePath);
        upload.getChunk();
        upload.allocateChunk();
        upload.sendChunk();
        upload.deleteChunkFile();
        upload.saveHashtable();
    }

    public static void main(String[] args) {
        Upload upload = new Upload("./test.pdf");
        upload.getChunk();
        upload.allocateChunk();
        upload.sendChunk();
        upload.deleteChunkFile();
        upload.saveHashtable();
    }


}
