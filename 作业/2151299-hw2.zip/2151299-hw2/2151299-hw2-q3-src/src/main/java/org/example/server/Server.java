package org.example.server;

import org.example.util.ReceiveFile;
import org.example.util.SendFile;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.stream.Collectors;

public class Server implements Runnable {
    private final int serverPort;
    private final String basePath;
    // request char mapping to the handle function
    private final Map<Character, RequestHandler> requestHandles = new HashMap<>();
    public Server(int serverPort, String basePath) {
        this.serverPort = serverPort;
        this.basePath = basePath;

        // init the map
        requestHandles.put('U', this::handleUpload);
        requestHandles.put('D', this::handleDownload);
        requestHandles.put('P', this::handleCUpload);
        requestHandles.put('G', this::handleCDownload);
        requestHandles.put('C', this::handleCheck);
    }

    @FunctionalInterface
    interface RequestHandler {
        void handle(DataInputStream dataInputStream, DataOutputStream dataOutputStream) throws Exception;
    }

    private void handleCheck(DataInputStream dataInputStream, DataOutputStream dataOutputStream) throws IOException {
        String fileName = getFileName(dataInputStream);
        Set<Integer> chunkIndex = getChunkSet(basePath, fileName + ".ser");
        System.out.println("get the set " + chunkIndex);
        dataOutputStream.writeInt(chunkIndex.size());
        for (int index: chunkIndex) {
            dataOutputStream.writeInt(index);
        }
    }

    private void handleCDownload(DataInputStream dataInputStream, DataOutputStream dataOutputStream) throws IOException {
        List<String> requiredFileNames = new ArrayList<>();
        String fileName = getFileName(dataInputStream);
        int fileNameCount = dataInputStream.readInt();
        for (int i = 0; i < fileNameCount; ++i) {
            requiredFileNames.add(getFileName(dataInputStream));
        }
        for (String chunkFileName: requiredFileNames) {
            Path chunkFilePath = Paths.get(basePath, chunkFileName);
            try (FileChannel fileChannel = FileChannel.open(chunkFilePath, StandardOpenOption.READ)) {
                SendFile sendFile = new SendFile(chunkFileName, fileChannel, dataOutputStream);
                sendFile.send();
                dataInputStream.readInt();
                System.out.println(chunkFilePath + " 成功发送");
            } catch (IOException e) {
                System.out.println(chunkFilePath + " 打开错误");
            }
        }
    }

    private void handleCUpload(DataInputStream dataInputStream, DataOutputStream dataOutputStream) throws Exception {
        handleUpload(dataInputStream, dataOutputStream);
    }

    private void handleDownload(DataInputStream dataInputStream, DataOutputStream dataOutputStream) throws IOException {
        // get the file name
        String fileName = getFileName(dataInputStream);
        // get the file chunk set
        Set<Integer> chunkIndex = getChunkSet(basePath, fileName + ".ser");
        System.out.println("获取集合 " + chunkIndex);
        // send the number of the file chunks
        dataOutputStream.writeInt(chunkIndex.size());
        // send each file
        for (int i: chunkIndex) {
            Path chunkFilePath = Paths.get(basePath, fileName + "#" + i);
            // send file
            try (FileChannel fileChannel = FileChannel.open(chunkFilePath, StandardOpenOption.READ)) {
                SendFile sendFile = new SendFile(fileName + "#" + i, fileChannel, dataOutputStream);
                sendFile.send();
                System.out.println(chunkFilePath + " 成功发送");
            } catch (IOException e) {
                System.out.println(chunkFilePath + " 打开失败");
            }
        }
    }

    private Set<Integer> getChunkSet(String basePath, String fileName) {
        Path filePath = Paths.get(basePath, fileName);
        Set<Integer> chunkIndex;
        try {
            chunkIndex = Files.lines(filePath)
                    .map(Integer::parseInt)
                    .collect(Collectors.toSet());
        } catch (IOException e) {
            chunkIndex = new HashSet<>();
        }
        return chunkIndex;
    }

    private void handleUpload(DataInputStream dataInputStream, DataOutputStream dataOutputStream) throws Exception {
        String fileName = getFileName(dataInputStream);
        int fileNameCount = dataInputStream.readInt();
        for (int i = 0; i < fileNameCount; ++i) {
            int fileNameLength = dataInputStream.readInt();
            ReceiveFile receiveFile = new ReceiveFile(fileNameLength, basePath, dataInputStream);
            int chunkIndex = receiveFile.receive();
            saveChunkIndex(basePath, fileName + ".ser", chunkIndex);
            dataOutputStream.writeInt(0);
        }
    }

    private void saveChunkIndex(String basePath, String fileName, int chunkIndex) throws IOException {
        Path filePath = Paths.get(basePath, fileName);
        Path parentDir = filePath.getParent();
        if (parentDir != null && !Files.exists(parentDir)) {
            Files.createDirectories(parentDir);
        }
        if (!Files.exists(filePath)) {
            String chunkIndexLine = chunkIndex + System.lineSeparator();
            Files.write(filePath, chunkIndexLine.getBytes(), StandardOpenOption.CREATE);
        } else {
            String chunkIndexLine = chunkIndex + System.lineSeparator();
            Files.write(filePath, chunkIndexLine.getBytes(), StandardOpenOption.APPEND);
        }
    }

    private void saveSet(String basePath, String fileName, Set<Integer> chunkIndex) throws IOException {
        Path filePath = Paths.get(basePath, fileName);
        Path parentDir = filePath.getParent();
        if (parentDir != null && !Files.exists(parentDir)) {
            Files.createDirectories(parentDir);
        }
        Set<Integer> chunkIndexOrigin = getChunkSet(basePath, fileName);
        chunkIndex.addAll(chunkIndexOrigin);
        System.out.println("after union " + chunkIndex);
        // save the set into the local file xxx.ser
        Files.write(filePath, chunkIndex.stream().map(Object::toString).toList());
        System.out.println("mapping table is saved successfully " + chunkIndex);
    }

    private String getFileName(DataInputStream dataInputStream) throws IOException {
        int nameLength = dataInputStream.readInt();
        byte[] nameBytes = new byte[nameLength];
        dataInputStream.readFully(nameBytes);
        String fileName = new String(nameBytes, StandardCharsets.UTF_8);
        System.out.println("接收文件名： "  + fileName);
        return fileName;
    }

    @Override
    public void run() {
        try (ServerSocket serverSocket = new ServerSocket(serverPort)) {
            System.out.println(serverPort + " 服务端已启用");
            while (true) {
                try (Socket socket = serverSocket.accept()) {
                    System.out.println("客户端连接： " + socket.getInetAddress() + serverPort);
                    handleClient(socket);
                }
            }
        } catch (IOException e) {
            System.out.println("服务端启用失败");
        }
    }

    private void handleClient(Socket socket) {
        try (DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
             DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream())) {
            Character request = (char) dataInputStream.readByte();
            if (requestHandles.containsKey(request)) {
                RequestHandler handler = requestHandles.get(request);
                handler.handle(dataInputStream, dataOutputStream);
            } else {
                System.out.println("请求错误");
            }
        } catch (Exception e) {
            System.out.println("打开socket IO流失败");
        }
    }
}
