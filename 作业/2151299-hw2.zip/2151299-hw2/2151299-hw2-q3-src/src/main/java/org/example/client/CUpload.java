package org.example.client;

import org.example.util.SendFile;

import java.io.*;
import java.net.Socket;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;

public class CUpload extends Upload {
    private final static String request = "P";
    private Map<Integer, List<Integer>> hashSent;
    private final String hashSentPath;
    public CUpload(String filePath) {
        super(filePath);
        hashSentPath = BASE_CHUNK_FILE_PATH + fileName + ".sent";
        getHashSent();
    }

    private void getHashSent() {
        try (ObjectInputStream objectInputStream = new ObjectInputStream(
                Files.newInputStream(Path.of(hashSentPath), StandardOpenOption.READ)
        )) {
            hashSent = (HashMap<Integer, List<Integer>>) objectInputStream.readObject();
        } catch (Exception e) {
            hashSent = new HashMap<>();
        }
    }

    @Override
    protected void sendChunk() {
        Socket[] sockets = new Socket[SERVER_PORTS.length];
        DataOutputStream[] dataOutputStreams = new DataOutputStream[SERVER_PORTS.length];
        DataInputStream[] dataInputStreams = new DataInputStream[SERVER_PORTS.length];
        try {
            for (int i = 0; i < sockets.length; ++i) {
                if (!hash.containsKey(SERVER_PORTS[i])) {
                    continue;
                }
                sockets[i] = new Socket(SERVER_HOST, SERVER_PORTS[i]);
                dataOutputStreams[i] = new DataOutputStream(sockets[i].getOutputStream());
                dataOutputStreams[i].write(request.getBytes(StandardCharsets.UTF_8));
                byte[] fileNameByte = fileName.getBytes(StandardCharsets.UTF_8);
                dataOutputStreams[i].writeInt(fileNameByte.length);
                dataOutputStreams[i].write(fileNameByte);
                List<Integer> v = hash.get(SERVER_PORTS[i]);
                List<Integer> vSent;
                if (hashSent.containsKey(SERVER_PORTS[i])) {
                    vSent = hashSent.get(SERVER_PORTS[i]);
                } else {
                    vSent = new ArrayList<>();
                }
                dataOutputStreams[i].writeInt(v.size() - vSent.size());
                for (Integer j: v) {
                    if (hashSent.containsKey(SERVER_PORTS[i]) && hashSent.get(SERVER_PORTS[i]).contains(j)) {
                        continue;
                    }
                    String chunkFilePath = BASE_CHUNK_FILE_PATH + fileName + "#" + j;
                    try (FileChannel fileChannel = FileChannel.open(Paths.get(chunkFilePath), StandardOpenOption.READ)) {
                        dataOutputStreams[i] = new DataOutputStream(sockets[i].getOutputStream());
                        dataInputStreams[i] = new DataInputStream(sockets[i].getInputStream());
                        SendFile sendFile = new SendFile(fileName + "#" + j, fileChannel, dataOutputStreams[i]);
                        sendFile.send();
                        sockets[i].setSoTimeout(500);
                        dataInputStreams[i].readInt();
                        System.out.println(chunkFilePath + " 成功上传");
                        if (hashSent.containsKey(SERVER_PORTS[i])) {
                            List<Integer> vTemp = hashSent.get(SERVER_PORTS[i]);
                            vTemp.add(j);
                            hashSent.put(SERVER_PORTS[i], vTemp);
                        } else {
                            hashSent.put(SERVER_PORTS[i], new ArrayList<>(List.of(j)));
                        }
                    } catch (IOException e) {
                        System.out.println(chunkFilePath + " 错误");
                        break;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("发送错误");
        } finally {
            for (int i = 0; i < sockets.length; ++i) {
                if (sockets[i] != null && !sockets[i].isClosed()) {
                    try {
                        sockets[i].close();
                    } catch (IOException e) {
                        System.out.println(sockets[i] + " 关闭失败");
                    }
                }
                if (dataOutputStreams[i] != null) {
                    try {
                        dataOutputStreams[i].close();
                    } catch (IOException e) {
                        System.out.println(dataOutputStreams[i] + " 关闭失败");
                    }
                }
            }
        }
    }

    private void getHashTable() {
        try (ObjectInputStream objectInputStream = new ObjectInputStream(
                Files.newInputStream(Path.of(hashTableFilePath), StandardOpenOption.READ)
        )) {
            hash = (HashMap<Integer, List<Integer>>) objectInputStream.readObject();
        } catch (Exception e) {
            allocateChunk();
        }
    }

    private void saveHashSent() {
        Path path = Path.of(hashSentPath);
        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                Files.newOutputStream(path, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)
        )) {
            objectOutputStream.writeObject(hashSent);
        } catch (IOException e) {
            System.out.println("哈希表保存失败");
        }
    }

    public static void uploadFile(String filePath) {
        CUpload cUpload = new CUpload(filePath);
        cUpload.getChunk();
        cUpload.getHashTable();
        cUpload.sendChunk();
        cUpload.deleteChunkFile();
        cUpload.saveHashtable();
        cUpload.saveHashSent();
    }

    public static void main(String[] args) {
        CUpload cUpload = new CUpload("./test.pdf");
        cUpload.getChunk();
        cUpload.getHashTable();
        cUpload.sendChunk();
        cUpload.deleteChunkFile();
        cUpload.saveHashtable();
        cUpload.saveHashSent();
    }
}
