package org.example.client;

import org.example.util.ReceiveFile;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public class CDownload extends Download {
    private static final String request = "G";
    private Map<Integer, List<Integer>> hashRequiredChunk;
    private Map<Integer, List<Integer>> hash;
    private final String hashTableFilePath;
    private final String hashReceivedPath;
    public CDownload(String fileName) {
        super(fileName);
        hashRequiredChunk = new HashMap<>();
        hash = new HashMap<>();
        hashTableFilePath = fileName + ".to";
        hashReceivedPath = fileName + ".received";
    }

    @Override
    protected void getChunk() {
        for (int port: SERVER_PORTS) {
            try (Socket socket = new Socket(SERVER_HOST, port);
                    DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                    DataInputStream dataInputStream = new DataInputStream(socket.getInputStream())) {
                dataOutputStream.write(request.getBytes(StandardCharsets.UTF_8));
                byte[] fileNameByte = fileName.getBytes(StandardCharsets.UTF_8);
                dataOutputStream.writeInt(fileNameByte.length);
                dataOutputStream.write(fileNameByte);
                List<Integer> v;
                if (hashRequiredChunk.containsKey(port)) {
                    v = hashRequiredChunk.get(port);
                } else {
                    v = new ArrayList<>();
                }
                dataOutputStream.writeInt(v.size());
                for (int chunkIndex: v) {
                    String chunkFileName = fileName + "#" + chunkIndex;
                    byte[] chunkFileNameByte = chunkFileName.getBytes(StandardCharsets.UTF_8);
                    dataOutputStream.writeInt(chunkFileNameByte.length);
                    dataOutputStream.write(chunkFileNameByte);
                }
                for (int i = 0; i < v.size(); ++i) {
                    int fileNameLength = dataInputStream.readInt();
                    ReceiveFile receiveFile = new ReceiveFile(fileNameLength, basePath, dataInputStream);
                    int chunkIndex = receiveFile.receive();
                    saveChunkIndex(chunkIndex);
                    dataOutputStream.writeInt(0);
                }
            } catch (Exception e) {
                System.out.println(port + " 链接失败");
            }
        }
    }

    private void saveChunkIndex(int chunkIndex) throws IOException {
        Path filePath = Paths.get(hashReceivedPath);
        if (!Files.exists(filePath)) {
            String chunkIndexLine = chunkIndex + System.lineSeparator();
            Files.write(filePath, chunkIndexLine.getBytes(), StandardOpenOption.CREATE);
        } else {
            String chunkIndexLine = chunkIndex + System.lineSeparator();
            Files.write(filePath, chunkIndexLine.getBytes(), StandardOpenOption.APPEND);
        }
    }

    private void getRequiredChunk() {
        Set<Integer> chunkIndex = getChunkSet(hashReceivedPath);
        for (Map.Entry<Integer, List<Integer>> entry: hash.entrySet()) {
            int port = entry.getKey();
            List<Integer> v = entry.getValue();

            for (Integer index: v) {
                if (!chunkIndex.contains(index)) {
                    if (hashRequiredChunk.containsKey(port)) {
                        List<Integer> vTemp = hashRequiredChunk.get(port);
                        vTemp.add(index);
                        hashRequiredChunk.put(port, vTemp);
                    } else {
                        hashRequiredChunk.put(port, new ArrayList<>(List.of(index)));
                    }
                }
            }
        }
        System.out.println("服务端及其所需文件块:");
        for (Map.Entry<Integer, List<Integer>> entry : hashRequiredChunk.entrySet()) {
            Integer key = entry.getKey();
            List<Integer> values = entry.getValue();

            System.out.print("服务端端口: " + key + ", 文件块序号: ");
            for (int i = 0; i < values.size(); i++) {
                System.out.print(values.get(i) + " ");
                if ((i + 1) % 10 == 0 || i == values.size() - 1) {
                    System.out.println();
                }
            }
            System.out.println(); // 换行
        }
    }

    private Set<Integer> getChunkSet(String fileName) {
        Path filePath = Paths.get(fileName);
        Set<Integer> chunkIndex;
        try {
            chunkIndex = Files.lines(filePath)
                    .map(Integer::parseInt)
                    .collect(Collectors.toSet());
        } catch (IOException e) {
            chunkIndex = new HashSet<>();
        }
        System.out.println(chunkIndex);
        return chunkIndex;
    }

    private void getHashTable() {
        try (ObjectInputStream objectInputStream = new ObjectInputStream(
                Files.newInputStream(Path.of(hashTableFilePath), StandardOpenOption.READ)
        )) {
            hash = (HashMap<Integer, List<Integer>>) objectInputStream.readObject();
        } catch (Exception e) {
            System.out.println("错误：没有ser文件");
        }
//        System.out.println("hash " + hash);
    }

    @Override
    protected boolean fileExists() {
        // get chunk count
        for (List<Integer> v: hash.values()) {
            chunkCount.addAndGet(v.size());
        }
        for (List<Integer> v: hashRequiredChunk.values()) {
            for (Integer chunkIndex: v) {
                Path chunkFilePath = Paths.get(basePath, fileName + "#" + chunkIndex);
                if (!Files.exists(chunkFilePath)) {
                    return false;
                }
            }
        }
        return chunkCount.get() > 0;
    }

    public static void downloadFile(String fileName) {
        CDownload cDownload = new CDownload(fileName);
        cDownload.getHashTable();
        cDownload.getRequiredChunk();
        cDownload.getChunk();
        if (cDownload.fileExists()) {
            cDownload.mergeFile();
//            cDownload.deleteChunkFile();
        } else {
            System.out.println(fileName + " 失败");
        }
    }
    public static void main(String[] args) {
        CDownload cDownload = new CDownload("test.pdf");
        cDownload.getHashTable();
        cDownload.getRequiredChunk();
        cDownload.getChunk();
        if (cDownload.fileExists()) {
            cDownload.mergeFile();
            cDownload.deleteChunkFile();
        } else {
            System.out.println("test.txt 不存在");
        }
    }
}
