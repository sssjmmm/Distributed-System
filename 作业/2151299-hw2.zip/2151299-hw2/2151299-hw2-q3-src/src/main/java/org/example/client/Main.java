package org.example.client;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("请输入指令(put/get/cput/cget/check/exit):");
            String command = scanner.nextLine();
            String prefix = command.split("\\s+")[0]; // 指令前面的部分
            String filePath = extractFileNameOrPath(command, prefix.toLowerCase());
            long startTime,endTime;
            switch (prefix) {
                case "put":
                    if (isFilePath(filePath)) {
                        System.out.println("正在上传: " + filePath);
                        startTime = System.currentTimeMillis();
                        Upload.uploadFile(filePath);
                        endTime = System.currentTimeMillis();
                        System.out.println("put用时: " + (endTime - startTime) + "ms");
                    } else {
                        System.out.println("无法找到该文件");
                    }
                    break;
                case "get":
                    startTime = System.currentTimeMillis();
                    Download.downloadFile(filePath);
                    endTime = System.currentTimeMillis();
                    System.out.println("get用时: " + (endTime - startTime) + "ms");
                    break;
                case "cput":
                    if (isFilePath(filePath)) {
                        startTime = System.currentTimeMillis();
                        CUpload.uploadFile(filePath);
                        endTime = System.currentTimeMillis();
                        System.out.println("cput用时: " + (endTime - startTime) + "ms");
                    } else {
                        System.out.println("无法找到该文件");
                    }
                    break;
                case "cget":
                    startTime = System.currentTimeMillis();
                    CDownload.downloadFile(filePath);
                    endTime = System.currentTimeMillis();
                    System.out.println("cget用时: " + (endTime - startTime) + "ms");
                    break;
                case "check":
                    CheckStatus checkObj = new CheckStatus(filePath);
                    checkObj.check();
                    break;
                case "exit":
                    return;
                default:
                    System.out.println("输入错误！请再次检查输入指令(put/get/cput/cget/check/exit)");
            }
        }
    }
    private static String extractFileNameOrPath(String command, String prefix) {
        return command.replaceFirst("^" + prefix.toLowerCase() + "\\s+", "");
    }
    private static boolean isFilePath(String filePath) {
        Path path = Paths.get(filePath);
        return Files.isRegularFile(path) && Files.exists(path);
    }
}
