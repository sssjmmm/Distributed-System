package org.example.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.*;

public class CheckStatus {
    private static String SERVER_HOST = "localhost";
    private static int[] SERVER_PORTS = {6001, 6002, 6003};
    private final String hashTableFilePath;
    private final String fileName;
    private final static String request = "C";
    private HashMap<Integer, List<Integer>> hash;
    private HashMap<Integer, List<Integer>> hashRemote;
    public CheckStatus(String fileName) {
        this.fileName = fileName;
        this.hashTableFilePath = fileName + ".to";
        this.hash = new HashMap<>();
        this.hashRemote = new HashMap<>();
    }
    private void checkServer() {
        for (int port: SERVER_PORTS) {
            List<Integer> v = new ArrayList<>();
            try (Socket socket = new Socket(SERVER_HOST, port);
                 DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                 DataInputStream dataInputStream = new DataInputStream(socket.getInputStream())) {
                System.out.println("服务端端口" + SERVER_HOST + ":" + port + " 正在启用...");
                dataOutputStream.write(request.getBytes(StandardCharsets.UTF_8));
                byte[] fileNameByte = fileName.getBytes(StandardCharsets.UTF_8);
                dataOutputStream.writeInt(fileNameByte.length);
                dataOutputStream.write(fileNameByte);
                int chunkCount = dataInputStream.readInt();
                for (int i = 0; i < chunkCount; ++i) {
                    v.add(dataInputStream.readInt());
                }
                hashRemote.put(port, v);
            } catch (IOException e){
                System.out.println(SERVER_HOST + ":" + port + " is down");
            }
        }
        printRemoteInfo(hashRemote);
    }
    private void checkFile() {
        try (ObjectInputStream objectInputStream = new ObjectInputStream(
                Files.newInputStream(Path.of(hashTableFilePath), StandardOpenOption.READ)
        )) {
            hash = (HashMap<Integer, List<Integer>>) objectInputStream.readObject();
        } catch (IOException e) {
            System.out.println("本地文件不存在");
        } catch (ClassNotFoundException e) {
            System.out.println("本地文件已损毁");
        }
    }

    private void printRemoteInfo(Map<Integer, List<Integer>> map) {
        boolean allEmpty = true;
        for (List<Integer> v: map.values()) {
            if (v.size() > 0) {
                allEmpty = false;
                break;
            }
        }
        if (allEmpty) {
            System.out.println("没有远程信息");
        } else {
            System.out.println("远程信息");
            printFileInfo(map);
        }
    }

    private void printFileInfo(Map<Integer, List<Integer>> map) {
        for (Map.Entry<Integer, List<Integer>> entry: map.entrySet()) {
            Integer port = entry.getKey();
            List<Integer> v = entry.getValue();
            System.out.println("服务端端口：" + SERVER_HOST + ":" + port);
            Collections.sort(v);
            System.out.println("文件块按ID排序:");
            for (int i = 0; i < v.size(); i++) {
                System.out.print(v.get(i) + " ");
                if ((i + 1) % 20 == 0 || i == v.size() - 1) {
                    System.out.println();
                }
            }
            System.out.println("共" + v.size() + "块\n");
        }
    }

    public void check() {
        checkServer();
        checkFile();
    }
}
