package org.example.server;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class Main {
    public static void main(String[] args) {
        int[] serverPorts = {6001, 6002, 6003};
        String[] basePaths = {"server01", "server02", "server03"};
        ExecutorService executorService = Executors.newFixedThreadPool(serverPorts.length);

        for (int i = 0; i < serverPorts.length; i++) {
            Server server = new Server(serverPorts[i], basePaths[i]);
            executorService.submit(server);
        }

        executorService.shutdown();
    }
}
